
import React, { useState, useRef, useEffect } from 'react';
import { Message } from '../types';

interface Props {
  messages: Message[];
  onSendMessage: (text: string) => void;
  nymeriaName: string;
  avatarUrl: string | null;
}

const ChatInterface: React.FC<Props> = ({ messages, onSendMessage, nymeriaName, avatarUrl }) => {
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      onSendMessage(input);
      setInput("");
    }
  };

  return (
    <div className="flex flex-col h-full bg-gray-950/40">
      {/* Header */}
      <div className="p-4 border-b border-white/5 bg-gray-900/80 backdrop-blur-md flex items-center gap-4">
        <div className="w-10 h-10 rounded-full bg-pink-500 flex items-center justify-center overflow-hidden border border-white/20">
          <img src={avatarUrl || ""} alt="N" className="w-full h-full object-cover" />
        </div>
        <div>
          <h3 className="font-bold text-white leading-none">{nymeriaName}</h3>
          <span className="text-xs text-green-400 flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span> Online
          </span>
        </div>
      </div>

      {/* Messages */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 space-y-4 scroll-smooth"
      >
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center p-8 opacity-50">
            <i className="fa-solid fa-comments text-4xl mb-4 text-pink-500"></i>
            <p>Comece um papo com a Nymeria! Ela está ansiosa por sua atenção.</p>
          </div>
        )}
        {messages.map((msg) => (
          <div 
            key={msg.id} 
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div className={`
              max-w-[85%] md:max-w-[70%] rounded-2xl p-4 shadow-xl
              ${msg.role === 'user' 
                ? 'bg-gradient-to-br from-indigo-600 to-indigo-700 text-white rounded-tr-none border border-white/10' 
                : 'bg-gray-800 text-gray-100 rounded-tl-none border border-white/5'
              }
            `}>
              <p className="text-sm md:text-base leading-relaxed whitespace-pre-wrap">{msg.text}</p>
              <div className="mt-1 text-[10px] opacity-40 text-right">
                {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Input */}
      <div className="p-4 border-t border-white/5 bg-gray-900/80 backdrop-blur-md">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Diga algo fofo para a Nymeria..."
            className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-pink-500/50 transition-all"
          />
          <button
            type="submit"
            disabled={!input.trim()}
            className="bg-pink-500 hover:bg-pink-600 disabled:opacity-50 text-white w-12 h-12 rounded-xl flex items-center justify-center transition-all transform active:scale-90"
          >
            <i className="fa-solid fa-paper-plane"></i>
          </button>
        </form>
      </div>
    </div>
  );
};

export default ChatInterface;
