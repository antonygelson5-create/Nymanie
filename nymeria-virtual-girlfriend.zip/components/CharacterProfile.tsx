
import React from 'react';

interface Props {
  avatarUrl: string | null;
  mood: 'happy' | 'jealous' | 'sweet' | 'scared' | 'excited';
}

const CharacterProfile: React.FC<Props> = ({ avatarUrl, mood }) => {
  const getMoodConfig = () => {
    switch(mood) {
      case 'jealous': return { color: 'text-red-400', label: 'Ciumenta 😤' };
      case 'sweet': return { color: 'text-pink-400', label: 'Dengosa 🥰' };
      default: return { color: 'text-green-400', label: 'Feliz ✨' };
    }
  };

  const moodConfig = getMoodConfig();

  return (
    <div className="flex flex-col p-6 space-y-6 overflow-y-auto">
      <div className="relative group">
        <div className="absolute -inset-1 bg-gradient-to-r from-pink-500 to-purple-600 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000"></div>
        <img 
          src={avatarUrl || 'https://picsum.photos/400/400'} 
          alt="Nymeria" 
          className="relative rounded-2xl w-full aspect-square object-cover shadow-2xl border border-white/10"
        />
      </div>

      <div className="space-y-4">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            Nymeria <span className="text-sm font-normal text-gray-400">15 anos</span>
          </h2>
          <p className={`text-sm font-medium ${moodConfig.color}`}>{moodConfig.label}</p>
        </div>

        <div className="space-y-2">
          <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">Interesses</p>
          <div className="flex flex-wrap gap-2">
            {['Anime', 'Romance', 'Terror', 'Animação', 'J-Pop'].map(tag => (
              <span key={tag} className="px-2 py-1 bg-white/5 border border-white/10 rounded-md text-xs text-gray-300">
                {tag}
              </span>
            ))}
          </div>
        </div>

        <div className="pt-4 border-t border-white/10">
          <p className="text-sm text-gray-400 italic">"Gosto de assistir filmes de terror agarradinha com você... mas não ouse olhar pra outra!"</p>
        </div>
      </div>
    </div>
  );
};

export default CharacterProfile;
